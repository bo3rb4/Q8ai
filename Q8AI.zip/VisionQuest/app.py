import os
import json
import sqlite3
import requests
import re
import html
import logging
from flask import Flask, request, jsonify, send_from_directory
from openai import OpenAI

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)

# ============ إعداد Flask ============
app = Flask(__name__, static_folder=".", static_url_path="")
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# ============ مفاتيح البيئة ============
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    app.logger.warning("OPENAI_API_KEY not found in environment variables")

FX_API = "https://api.exchangerate.host/convert"
WEATHER_API = "https://api.open-meteo.com/v1/forecast"

# تهيئة عميل OpenAI
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# ============ قاعدة بيانات TODO (SQLite) ============
DB_PATH = "todo.db"

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        cur = con.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS todos(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)
        con.commit()

init_db()

def todo_add(title: str) -> str:
    if not title.strip():
        return "لا يمكن إضافة مهمة فارغة."
    with sqlite3.connect(DB_PATH) as con:
        cur = con.cursor()
        cur.execute("INSERT INTO todos(title) VALUES(?)", (title.strip(),))
        con.commit()
        return f"تمت إضافة المهمة بنجاح: {title.strip()}"

def todo_list() -> str:
    with sqlite3.connect(DB_PATH) as con:
        cur = con.cursor()
        cur.execute("SELECT id,title,created_at FROM todos ORDER BY id")
        rows = cur.fetchall()
        if not rows:
            return "لا توجد مهام."
        lines = [f"{r[0]}. {r[1]} (أضيفت {r[2]})" for r in rows]
        return "مهامك:\n" + "\n".join(lines)

def todo_delete(task_id: int) -> str:
    with sqlite3.connect(DB_PATH) as con:
        cur = con.cursor()
        cur.execute("DELETE FROM todos WHERE id = ?", (task_id,))
        con.commit()
        if cur.rowcount == 0:
            return f"لا توجد مهمة برقم {task_id}."
        return f"تم حذف المهمة رقم {task_id}."

# ============ أدوات خارجية ============
def fx_convert(amount: float, from_ccy: str, to_ccy: str) -> str:
    try:
        params = {"from": from_ccy.upper(), "to": to_ccy.upper(), "amount": amount}
        r = requests.get(FX_API, params=params, timeout=10)
        j = r.json()
        if "result" in j and j["result"] is not None:
            return f"{amount} {from_ccy.upper()} ≈ {j['result']:.2f} {to_ccy.upper()}"
        return "تعذر حساب التحويل الآن."
    except Exception as e:
        app.logger.error(f"Currency conversion error: {e}")
        return "خطأ في خدمة التحويل."

def get_weather(city: str) -> str:
    city_map = {
        "kuwait": (29.3759, 47.9774),
        "الكويت": (29.3759, 47.9774),
        "hawalli": (29.3333, 48.0000),
        "حولي": (29.3333, 48.0000),
        "ahmadi": (29.0769, 48.0839),
        "الأحمدي": (29.0769, 48.0839),
        "riyadh": (24.7136, 46.6753),
        "الرياض": (24.7136, 46.6753),
        "dubai": (25.2048, 55.2708),
        "دبي": (25.2048, 55.2708)
    }
    key = city.strip().lower()
    latlon = city_map.get(key, city_map["kuwait"])
    try:
        params = {"latitude": latlon[0], "longitude": latlon[1], "hourly": "temperature_2m", "forecast_days": 1}
        r = requests.get(WEATHER_API, params=params, timeout=10)
        j = r.json()
        temps = j.get("hourly", {}).get("temperature_2m", [])
        if not temps:
            return f"لا تتوفر بيانات طقس لـ {city} الآن."
        now_temp = temps[0]
        return f"طقس {city}: الحرارة الآن تقريباً {now_temp}°C."
    except Exception as e:
        app.logger.error(f"Weather API error: {e}")
        return "تعذر جلب الطقس حالياً."

# ============ قاموس اللهجة الكويتية ============
KUWAITI_DIALECT_MAP = {
    # كلمات المكان
    "هني": "هنا",
    "هناك": "هناك",
    "وين": "أين",
    "هنيك": "هناك",
    
    # كلمات الاستفهام
    "شلون": "كيف", 
    "اشلون": "كيف",
    "شنو": "ماذا",
    "شنهو": "ماذا", 
    "متى": "متى",
    "ليش": "لماذا",
    "مين": "من",
    "شكو": "ما المشكلة",
    
    # كلمات الوقت
    "توني": "الآن",
    "عقب": "بعد",
    "بعدين": "بعد ذلك",
    "امس": "أمس",
    "باجر": "غداً",
    "اليوم": "اليوم",
    
    # كلمات التأكيد والنفي
    "زين": "جيد",
    "مب": "ليس",
    "ما": "لا",
    "عاد": "إذن",
    "بس": "لكن",
    "اذا": "إذا",
    "لو": "إذا",
    
    # كلمات الفعل
    "وريني": "أرني",
    "قلي": "قل لي", 
    "علمني": "علمني",
    "زيد": "أضف",
    "امسح": "احذف",
    "دور": "ابحث",
    "شوف": "انظر",
    "اشتري": "اشتري",
    "اروح": "أذهب",
    
    # كلمات أخرى شائعة
    "ياخي": "يا رجل",
    "حبيبي": "حبيبي", 
    "والله": "والله",
    "ان شاء الله": "إن شاء الله",
    "ما صدقت": "أخيراً",
    "شكلي": "أعتقد",
    "عبالي": "ظننت",
    "وناسة": "جميل",
    "شهي": "لذيذ",
    "هاي": "هذه",
    "هذيل": "هؤلاء",
    "هذيله": "هؤلاء"
}

def normalize_kuwaiti_text(text: str) -> str:
    """تحويل النص من اللهجة الكويتية إلى العربية الفصحى لتحسين الفهم"""
    words = text.split()
    normalized_words = []
    for word in words:
        # إزالة علامات الترقيم من نهاية الكلمة للمطابقة
        clean_word = word.rstrip('.,!?؟،.')
        punct = word[len(clean_word):]
        
        if clean_word in KUWAITI_DIALECT_MAP:
            normalized_words.append(KUWAITI_DIALECT_MAP[clean_word] + punct)
        else:
            normalized_words.append(word)
    return " ".join(normalized_words)

# ============ بحث ويب ============
_UA = {"User-Agent": "Mozilla/5.0 (compatible; LLM-Tools-Demo/1.0)"}

def web_search(query: str, max_results: int = 5) -> str:
    """
    بحث سريع عبر DuckDuckGo (نسخة HTML خفيفة) + رجوع أوّل النتائج مع عناوين وروابط.
    """
    try:
        url = "https://duckduckgo.com/html/"
        params = {"q": query}
        r = requests.get(url, params=params, headers=_UA, timeout=12)
        r.raise_for_status()
        html_doc = r.text
        # استخراج النتائج (العناوين + الروابط)
        pattern = re.compile(r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.I|re.S)
        results = []
        for m in pattern.finditer(html_doc):
            link = html.unescape(m.group(1))
            title = re.sub(r"(?s)<.*?>", "", m.group(2))  # إزالة أي HTML داخل العنوان
            if link.startswith("http"):
                results.append({"title": title.strip(), "url": link.strip()})
            if len(results) >= max_results:
                break
        if not results:
            return f"لم أجد نتائج واضحة لعبارة البحث: {query}"
        lines = [f"- {it['title']}\n  {it['url']}" for it in results]
        return "أهم النتائج:\n" + "\n".join(lines)
    except Exception as e:
        app.logger.error(f"Web search error: {e}")
        return "تعذر إجراء البحث حالياً."

# ============ تعريف الأدوات (Tools) ============
TOOLS = [
    {
        "type": "function", 
        "function": {
            "name": "todo_add",
            "description": "Add a todo item (Arabic allowed).",
            "parameters": {
                "type": "object",
                "properties": {"title": {"type": "string"}},
                "required": ["title"]
            }
        }
    },
    {
        "type": "function", 
        "function": {
            "name": "todo_list",
            "description": "List all todo items.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function", 
        "function": {
            "name": "todo_delete",
            "description": "Delete a todo item by id.",
            "parameters": {
                "type": "object",
                "properties": {"task_id": {"type": "integer"}},
                "required": ["task_id"]
            }
        }
    },
    {
        "type": "function", 
        "function": {
            "name": "fx_convert",
            "description": "Convert currency (amount, from, to).",
            "parameters": {
                "type": "object",
                "properties": {
                    "amount": {"type": "number"},
                    "from_ccy": {"type": "string"},
                    "to_ccy": {"type": "string"}
                },
                "required": ["amount", "from_ccy", "to_ccy"]
            }
        }
    },
    {
        "type": "function", 
        "function": {
            "name": "get_weather",
            "description": "Get simple weather info for a city name.",
            "parameters": {
                "type": "object",
                "properties": {"city": {"type": "string"}},
                "required": ["city"]
            }
        }
    },
    {
        "type": "function", 
        "function": {
            "name": "web_search",
            "description": "Search the web and return top results (title + url).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"}, 
                    "max_results": {"type": "integer"}
                },
                "required": ["query"]
            }
        }
    }
]

def call_tool(tool_call):
    """استدعاء الأدوات بناءً على اسم الأداة والمعاملات"""
    try:
        name = tool_call.function.name
        args = json.loads(tool_call.function.arguments or "{}")
        
        if name == "todo_add":
            return todo_add(args["title"])
        elif name == "todo_list":
            return todo_list()
        elif name == "todo_delete":
            return todo_delete(int(args["task_id"]))
        elif name == "fx_convert":
            return fx_convert(float(args["amount"]), args["from_ccy"], args["to_ccy"])
        elif name == "get_weather":
            return get_weather(args["city"])
        elif name == "web_search":
            return web_search(args["query"], int(args.get("max_results", 5)))
        else:
            return "Tool not found."
    except Exception as e:
        app.logger.error(f"Tool execution error: {e}")
        return f"خطأ في تنفيذ الأداة: {str(e)}"

# ============ مسار الشات ============
@app.route("/chat", methods=["POST"])
def chat():
    try:
        if not client:
            return jsonify({"error": "يرجى إعداد مفتاح OpenAI API أولاً"}), 500
            
        data = request.get_json(force=True)
        user_msg = data.get("message", "").strip()

        if not user_msg:
            return jsonify({"error": "رسالة فارغة"}), 400

        # تطبيع النص لتحويل اللهجة الكويتية لفهم أفضل
        original_msg = user_msg
        normalized_msg = normalize_kuwaiti_text(user_msg)

        # نوجّه النموذج لاستعمال الأدوات المتاحة
        sys_prompt = (
            "You are a helpful Arabic assistant that understands both standard Arabic and Kuwaiti dialect. "
            "You understand Kuwaiti dialect words like: هني (here), شلون (how), شنو/شنهو (what), وين (where), "
            "متى (when), ليش (why), اشلون (how), شكو (what's wrong), ياخي (buddy), اذا (if), عاد (then), "
            "بعدين (later), توني (just now), بس (but/just), زين (good), ما صدقت (finally), شكلي (I think), "
            "عبالي (I thought), وناسة (nice), طاح (fell), شهي (tasty), عقب (after), مب (not), هاي (this), "
            "هذيل/هذيله (these), and many others. "
            "You can help with todo list management, weather queries, currency conversion, and web searches. "
            "Always respond in Arabic (preferably in Kuwaiti dialect when the user uses it) and be friendly and natural."
        )

        # نستخدم الرسالة المطبعة للـ AI مع الاحتفاظ بالرسالة الأصلية للسياق
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": f"Original message: {original_msg}\nNormalized: {normalized_msg}"}
        ]

        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            tools=TOOLS,
            tool_choice="auto"
        )

        choice = resp.choices[0]
        if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
            # نفّذ الأدوات المطلوبة
            tool_messages = []
            for tc in choice.message.tool_calls:
                result = call_tool(tc)
                tool_messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "name": tc.function.name,
                    "content": result
                })

            # أعد الطلب مع نتائج الأدوات للحصول على جواب نهائي مصاغ
            messages.append({
                "role": "assistant", 
                "content": choice.message.content,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments
                        }
                    } for tc in choice.message.tool_calls
                ]
            })
            messages.extend(tool_messages)
            
            final = client.chat.completions.create(
                model="gpt-4o",
                messages=messages
            )
            return jsonify({"answer": final.choices[0].message.content})

        return jsonify({"answer": choice.message.content})
    
    except Exception as e:
        app.logger.error(f"Chat error: {e}")
        error_msg = str(e)
        
        # معالجة أخطاء OpenAI API المحددة
        if "429" in error_msg or "insufficient_quota" in error_msg or "quota" in error_msg.lower():
            return jsonify({
                "error": "تجاوزت حساب OpenAI الحد المسموح أو نفد الرصيد.\n\n"
                        "الحلول:\n"
                        "• تأكد من وجود رصيد كافي في حساب OpenAI\n" 
                        "• انتظر حتى يتجدد الحد اليومي\n"
                        "• ارفع خطة الاشتراك إذا لزم الأمر\n\n"
                        "راجع: https://platform.openai.com/usage"
            }), 429
        elif "401" in error_msg or "unauthorized" in error_msg.lower():
            return jsonify({
                "error": "مفتاح OpenAI API غير صحيح أو منتهي الصلاحية.\n"
                        "يرجى التحقق من صحة المفتاح في إعدادات البيئة."
            }), 401
        else:
            return jsonify({"error": "حدث خطأ في معالجة الطلب"}), 500

# ============ عرض الصفحة ============
@app.route("/")
def serve_html():
    return send_from_directory(".", "index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)