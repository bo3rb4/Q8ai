# Arabic AI Assistant with Tools

## Overview

This is a Flask-based Arabic language AI assistant that integrates with OpenAI's API to provide intelligent conversational capabilities with full support for Kuwaiti dialect. The application features a web interface for chatting with an AI assistant that understands both standard Arabic and Kuwaiti colloquial expressions (like "هني" for "here", "شلون" for "how", "وريني" for "show me"). It can perform core tasks including todo list management, weather queries, currency conversion, and web search. The system is designed to handle Arabic text and Kuwaiti dialect naturally, providing a culturally appropriate interface for Kuwaiti users. Mathematical calculations, server time display, and URL summarization capabilities have been removed to focus on the core functionality.

## User Preferences

Preferred communication style: Simple, everyday language.
Language support: Full support for Kuwaiti dialect alongside standard Arabic - user wants the AI to understand and respond to Kuwaiti colloquial expressions like "هني" (here), "شلون" (how), "وريني" (show me), etc.

## System Architecture

### Frontend Architecture
- **Single Page Application**: Uses vanilla HTML, CSS, and JavaScript for a simple web interface
- **Arabic Language Support**: Full RTL (right-to-left) text direction and Arabic font support
- **Responsive Design**: Mobile-friendly interface with gradient styling and modern CSS
- **Real-time Interaction**: Direct API communication with the Flask backend for chat functionality

### Backend Architecture
- **Flask Web Framework**: Lightweight Python web server handling HTTP requests and responses
- **RESTful API Design**: JSON-based communication between frontend and backend
- **Function Calling Architecture**: Integration with OpenAI's function calling capabilities for tool execution
- **Modular Tool System**: Separate functions for different capabilities (todo management, weather, currency, web search)

### Data Storage
- **SQLite Database**: Local file-based database for todo list persistence
- **Simple Schema**: Single table structure for todo items with auto-incrementing IDs and timestamps
- **Connection Management**: Context-managed database connections for proper resource handling

### AI Integration
- **OpenAI API Integration**: Uses GPT models with function calling capabilities
- **Tool Registration**: Structured function definitions for AI tool selection and execution
- **Arabic Language Processing**: Configured for Arabic language input and output

### External Service Integration
- **Weather API**: Integration with Open-Meteo API for weather forecast data
- **Currency Exchange API**: Uses exchangerate.host for real-time currency conversion
- **Error Handling**: Graceful fallback mechanisms for external service failures

## External Dependencies

### AI Services
- **OpenAI API**: Core AI functionality requiring API key configuration
- **GPT Models**: Uses OpenAI's chat completion models with function calling

### External APIs
- **Open-Meteo Weather API**: Free weather data service (no API key required)
- **ExchangeRate-Host API**: Currency conversion service (no API key required)

### Python Libraries
- **Flask**: Web framework for HTTP server functionality
- **OpenAI**: Official OpenAI Python client library
- **SQLite3**: Built-in Python database interface
- **Requests**: HTTP client for external API calls

### Database
- **SQLite**: Embedded database for local data persistence
- **File-based Storage**: Database stored as `todo.db` file in project directory

### Environment Configuration
- **OPENAI_API_KEY**: Required environment variable for OpenAI API access
- **SESSION_SECRET**: Flask session security (defaults to development key)
- **Debug Mode**: Configurable logging and debug settings